import React, {useState} from "react";
import { useNavigate } from "react-router-dom";
import "../styles/buy.css";

const Buy  = () => {
    const [formData, setFormData] = React.useState({
        name: "",
        email: "",
        password: "",
        address: "",
        paymentMethod: "",
    });

    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log("Order Data: ", formData);
        alert("Order placed successfully!!!");
        navigate("/");
    }

    return (
        <div className="buy-container">
        <h2>Checkout Page</h2>
        <form action="" className="buy-form" onSubmit={handleSubmit}>
            <div className="form-group">
                <label>Name: </label>
                <input type="text" name="name" value={formData.name} onChange={handleChange} required/>
            </div>

            <div className="form-group">
                <label>Email: </label>
                <input type="Email" name="email" value={formData.email} onChange={handleChange} required/>
            </div>

            <div className="form-group">
                <label>Password: </label>
                <input type="password" name="password" value={formData.password} onChange={handleChange} required/>
            </div>

            <div className="form-group">
                <label>Address: </label>
                <textarea name="address" value={formData.address} onChange={handleChange} required/>
            </div>

            <div className="form-group">
                <label>Payment Method: </label>
                <select name="paymentMEthod" value={formData.paymentMethod} onChange={handleChange}>
                    <option value = "Credit Card">Credit Card</option>
                    <option value = "Debit Card">Debit Card</option>
                    <option value = "UPI">UPI</option>
                    <option value = "Cash on Delivery">Cash on Delivery</option>
                </select>
            </div>
            
            <button type="submit" className="submit-btn">Place Order</button>
        </form>
        </div>
    );
};

export default Buy;