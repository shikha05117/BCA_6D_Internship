import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import "../styles/productDetails.css";

const ProductDetails = ({ products }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const product = products.find((item) => item.id === id);

  if (!product) {
    return <h2>Product not found</h2>;
  }

  const handleBuyNow = () => {
    navigate("/buy");
  };

  return (
    <div className="product-container">
      <img src={product.images} alt={product.name} />
      <h1>{product.name}</h1>
      <p className="price">Rs. {product.price}/-</p>
      <p>{product.description}</p>
      <div className="buttons">
        <button className="buy" onClick={handleBuyNow}>Buy Now</button>
        <button className="cart">Add To Cart</button>
      </div>
    </div>
  );
};

export default ProductDetails;
