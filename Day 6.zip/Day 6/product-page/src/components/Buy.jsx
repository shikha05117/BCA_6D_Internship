import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/buy.css";
import axios from "axios";

const Buy = () => {
    const [formData, setFormData] = React.useState({
        name: "",
        email: "",
        password: "",
        address: "",
        amount: "",
        paymentMethod: "Razorpay",
    });

    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const loadRazorpay = () => {
        const script = document.createElement("script");
        script.src = "https://checkout.razorpay.com/v1/checkout.js";
        script.onload = () => handlePayment();
        script.onerror = () => console.log("Razorpay SDK failed to load. ");
        document.body.appendChild(script);
    }
    const handlePayment = async () => {
        try {
            const order = await axios.post("http://localhost:5000/create-order", {
                amount: formData.amount,
            });

            const options = {
                key: "rzp_test_WgxamtVupSULV6",
                amount: order.data.amount,
                currency: "INR",
                name: "Organic Products",
                description: "Test",
                order_id: order.data.id,
                handler: (response) => {
                    console.log("Payment Successful!");
                },
                prefill: {
                    name: formData.name,
                    email: formData.email,
                },
                notes: {
                    address: formData.address,
                },
                theme: {
                    color: "#3399cc",
                },
            };

            const paymentObject = new window.Razorpay(options);
            paymentObject.open();
        } catch (error) {
            console.log("Error in payment", error);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        loadRazorpay();
    };

    return (
        <div className="buy-container">
            <h2>Checkout Page</h2>
            <form action="" className="buy-form" onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Name: </label>
                    <input type="text" name="name" value={formData.name} onChange={handleChange} required />
                </div>

                <div className="form-group">
                    <label>Email: </label>
                    <input type="Email" name="email" value={formData.email} onChange={handleChange} required />
                </div>

                <div className="form-group">
                    <label>Password: </label>
                    <input type="password" name="password" value={formData.password} onChange={handleChange} required />
                </div>

                <div className="form-group">
                    <label>Address: </label>
                    <textarea name="address" value={formData.address} onChange={handleChange} required />
                </div>

                <div className="form-group">
                    <label>Amount (INR):</label>
                    <input
                        type="number"
                        name="amount"
                        value={formData.amount}
                        onChange={handleChange}
                        required
                    />
                </div>

                {/* <div className="form-group">
                <label>Payment Method: </label>
                <select name="paymentMEthod" value={formData.paymentMethod} onChange={handleChange}>
                    <option value = "Credit Card">Credit Card</option>
                    <option value = "Debit Card">Debit Card</option>
                    <option value = "UPI">UPI</option>
                    <option value = "Cash on Delivery">Cash on Delivery</option>
                </select>
            </div> */}

                <button type="submit" className="submit-btn">Place Order</button>
            </form>
        </div>
    );
};

export default Buy;